package ftp.pouya.app.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_ui1{

public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
//BA.debugLineNum = 2;BA.debugLine="AutoScaleAll"[ui1/General script]
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
//BA.debugLineNum = 4;BA.debugLine="EditText1.SetLeftAndRight (60,75%x)"[ui1/General script]
views.get("edittext1").vw.setLeft((int)(60d));
views.get("edittext1").vw.setWidth((int)((75d / 100 * width) - (60d)));
//BA.debugLineNum = 5;BA.debugLine="EditText2.SetLeftAndRight (60,75%x)"[ui1/General script]
views.get("edittext2").vw.setLeft((int)(60d));
views.get("edittext2").vw.setWidth((int)((75d / 100 * width) - (60d)));
//BA.debugLineNum = 6;BA.debugLine="EditText3.SetLeftAndRight (60,75%x)"[ui1/General script]
views.get("edittext3").vw.setLeft((int)(60d));
views.get("edittext3").vw.setWidth((int)((75d / 100 * width) - (60d)));
//BA.debugLineNum = 7;BA.debugLine="saveButton.SetLeftAndRight (110,55%x)"[ui1/General script]
views.get("savebutton").vw.setLeft((int)(110d));
views.get("savebutton").vw.setWidth((int)((55d / 100 * width) - (110d)));
//BA.debugLineNum = 9;BA.debugLine="EditText2.Top = EditText1.Bottom +5dip"[ui1/General script]
views.get("edittext2").vw.setTop((int)((views.get("edittext1").vw.getTop() + views.get("edittext1").vw.getHeight())+(5d * scale)));
//BA.debugLineNum = 10;BA.debugLine="EditText3.Top = EditText2.Bottom +5dip"[ui1/General script]
views.get("edittext3").vw.setTop((int)((views.get("edittext2").vw.getTop() + views.get("edittext2").vw.getHeight())+(5d * scale)));
//BA.debugLineNum = 11;BA.debugLine="saveButton.Top = EditText3.Bottom +15dip"[ui1/General script]
views.get("savebutton").vw.setTop((int)((views.get("edittext3").vw.getTop() + views.get("edittext3").vw.getHeight())+(15d * scale)));

}
}