package ftp.pouya.app;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class main_subs_0 {


public static RemoteObject  _activity_create(RemoteObject _firsttime) throws Exception{
try {
		Debug.PushSubsStack("Activity_Create (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,33);
if (RapidSub.canDelegate("activity_create")) { return ftp.pouya.app.main.remoteMe.runUserSub(false, "main","activity_create", _firsttime);}
Debug.locals.put("FirstTime", _firsttime);
 BA.debugLineNum = 33;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
Debug.ShouldStop(1);
 BA.debugLineNum = 35;BA.debugLine="Activity.LoadLayout(\"ui1\")";
Debug.ShouldStop(4);
main.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("ui1")),main.mostCurrent.activityBA);
 BA.debugLineNum = 37;BA.debugLine="End Sub";
Debug.ShouldStop(16);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_pause(RemoteObject _userclosed) throws Exception{
try {
		Debug.PushSubsStack("Activity_Pause (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,43);
if (RapidSub.canDelegate("activity_pause")) { return ftp.pouya.app.main.remoteMe.runUserSub(false, "main","activity_pause", _userclosed);}
Debug.locals.put("UserClosed", _userclosed);
 BA.debugLineNum = 43;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
Debug.ShouldStop(1024);
 BA.debugLineNum = 45;BA.debugLine="End Sub";
Debug.ShouldStop(4096);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_resume() throws Exception{
try {
		Debug.PushSubsStack("Activity_Resume (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,39);
if (RapidSub.canDelegate("activity_resume")) { return ftp.pouya.app.main.remoteMe.runUserSub(false, "main","activity_resume");}
 BA.debugLineNum = 39;BA.debugLine="Sub Activity_Resume";
Debug.ShouldStop(64);
 BA.debugLineNum = 41;BA.debugLine="End Sub";
Debug.ShouldStop(256);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _globals() throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 25;BA.debugLine="Private EditText1 As EditText";
main.mostCurrent._edittext1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 26;BA.debugLine="Private EditText2 As EditText";
main.mostCurrent._edittext2 = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 27;BA.debugLine="Private EditText3 As EditText";
main.mostCurrent._edittext3 = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 28;BA.debugLine="Private saveButton As Button";
main.mostCurrent._savebutton = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 29;BA.debugLine="Dim s As String";
main.mostCurrent._s = RemoteObject.createImmutable("");
 //BA.debugLineNum = 30;BA.debugLine="Dim ftp1 As FTP";
main.mostCurrent._ftp1 = RemoteObject.createNew ("anywheresoftware.b4a.net.FTPWrapper");
 //BA.debugLineNum = 31;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main_subs_0._process_globals();
starter_subs_0._process_globals();
main.myClass = BA.getDeviceClass ("ftp.pouya.app.main");
starter.myClass = BA.getDeviceClass ("ftp.pouya.app.starter");
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _savebutton_click() throws Exception{
try {
		Debug.PushSubsStack("saveButton_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,48);
if (RapidSub.canDelegate("savebutton_click")) { return ftp.pouya.app.main.remoteMe.runUserSub(false, "main","savebutton_click");}
RemoteObject _st = RemoteObject.createImmutable("");
 BA.debugLineNum = 48;BA.debugLine="Sub saveButton_Click";
Debug.ShouldStop(32768);
 BA.debugLineNum = 49;BA.debugLine="Dim st As String";
Debug.ShouldStop(65536);
_st = RemoteObject.createImmutable("");Debug.locals.put("st", _st);
 BA.debugLineNum = 51;BA.debugLine="s=EditText1.Text&\"   \"&EditText2.Text&\"   \"&EditT";
Debug.ShouldStop(262144);
main.mostCurrent._s = RemoteObject.concat(main.mostCurrent._edittext1.runMethod(true,"getText"),RemoteObject.createImmutable("   "),main.mostCurrent._edittext2.runMethod(true,"getText"),RemoteObject.createImmutable("   "),main.mostCurrent._edittext3.runMethod(true,"getText"));
 BA.debugLineNum = 52;BA.debugLine="If File.Exists(File.DirRootExternal,\"text.txt\")=";
Debug.ShouldStop(524288);
if (RemoteObject.solveBoolean("=",main.mostCurrent.__c.getField(false,"File").runMethod(true,"Exists",(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirRootExternal")),(Object)(RemoteObject.createImmutable("text.txt"))),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 53;BA.debugLine="File.Copy(File.DirAssets,\"text.txt\",File.DirRoo";
Debug.ShouldStop(1048576);
main.mostCurrent.__c.getField(false,"File").runVoidMethod ("Copy",(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirAssets")),(Object)(BA.ObjectToString("text.txt")),(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirRootExternal")),(Object)(RemoteObject.createImmutable("text.txt")));
 };
 BA.debugLineNum = 56;BA.debugLine="If File.Exists(File.DirInternal,\"dl.txt\")=False";
Debug.ShouldStop(8388608);
if (RemoteObject.solveBoolean("=",main.mostCurrent.__c.getField(false,"File").runMethod(true,"Exists",(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirInternal")),(Object)(RemoteObject.createImmutable("dl.txt"))),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 57;BA.debugLine="File.Copy(File.DirAssets,\"dl.txt\",File.DirInter";
Debug.ShouldStop(16777216);
main.mostCurrent.__c.getField(false,"File").runVoidMethod ("Copy",(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirAssets")),(Object)(BA.ObjectToString("dl.txt")),(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirInternal")),(Object)(RemoteObject.createImmutable("dl.txt")));
 };
 BA.debugLineNum = 60;BA.debugLine="File.WriteString(File.DirRootExternal,\"text.txt\",";
Debug.ShouldStop(134217728);
main.mostCurrent.__c.getField(false,"File").runVoidMethod ("WriteString",(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirRootExternal")),(Object)(BA.ObjectToString("text.txt")),(Object)(main.mostCurrent._s));
 BA.debugLineNum = 61;BA.debugLine="ftp1.Initialize(\"ftp1\",\"ftp.exmpl.ir\",21,\"user\",\"";
Debug.ShouldStop(268435456);
main.mostCurrent._ftp1.runVoidMethod ("Initialize",main.processBA,(Object)(BA.ObjectToString("ftp1")),(Object)(BA.ObjectToString("ftp.exmpl.ir")),(Object)(BA.numberCast(int.class, 21)),(Object)(BA.ObjectToString("user")),(Object)(RemoteObject.createImmutable("passwd")));
 BA.debugLineNum = 62;BA.debugLine="ftp1.PassiveMode=True";
Debug.ShouldStop(536870912);
main.mostCurrent._ftp1.runMethod(true,"setPassiveMode",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 65;BA.debugLine="ftp1.UploadFile(File.DirRootExternal,\"text.txt\",";
Debug.ShouldStop(1);
main.mostCurrent._ftp1.runVoidMethod ("UploadFile",main.processBA,(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirRootExternal")),(Object)(BA.ObjectToString("text.txt")),(Object)(main.mostCurrent.__c.getField(true,"False")),(Object)(RemoteObject.createImmutable("/myText.txt")));
 BA.debugLineNum = 68;BA.debugLine="ftp1.DownloadFile(\"/myText.txt\",False,File.DirIn";
Debug.ShouldStop(8);
main.mostCurrent._ftp1.runVoidMethod ("DownloadFile",main.processBA,(Object)(BA.ObjectToString("/myText.txt")),(Object)(main.mostCurrent.__c.getField(true,"False")),(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirInternal")),(Object)(RemoteObject.createImmutable("dl.txt")));
 BA.debugLineNum = 71;BA.debugLine="st=File.ReadString(File.DirInternal,\"dl.txt\")";
Debug.ShouldStop(64);
_st = main.mostCurrent.__c.getField(false,"File").runMethod(true,"ReadString",(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirInternal")),(Object)(RemoteObject.createImmutable("dl.txt")));Debug.locals.put("st", _st);
 BA.debugLineNum = 72;BA.debugLine="Msgbox(st,\"your text is:\")";
Debug.ShouldStop(128);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence(_st)),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("your text is:"))),main.mostCurrent.activityBA);
 BA.debugLineNum = 73;BA.debugLine="End Sub";
Debug.ShouldStop(256);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}