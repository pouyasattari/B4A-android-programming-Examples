
package calculator.pouya.app;

import java.io.IOException;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.PCBA;
import anywheresoftware.b4a.pc.RDebug;
import anywheresoftware.b4a.pc.RemoteObject;
import anywheresoftware.b4a.pc.RDebug.IRemote;
import anywheresoftware.b4a.pc.Debug;
import anywheresoftware.b4a.pc.B4XTypes.B4XClass;
import anywheresoftware.b4a.pc.B4XTypes.DeviceClass;

public class main implements IRemote{
	public static main mostCurrent;
	public static RemoteObject processBA;
    public static boolean processGlobalsRun;
    public static RemoteObject myClass;
    public static RemoteObject remoteMe;
	public main() {
		mostCurrent = this;
	}
    public RemoteObject getRemoteMe() {
        return remoteMe;    
    }
    
	public static void main (String[] args) throws Exception {
		new RDebug(args[0], Integer.parseInt(args[1]), Integer.parseInt(args[2]), args[3]);
		RDebug.INSTANCE.waitForTask();

	}
    static {
        anywheresoftware.b4a.pc.RapidSub.moduleToObject.put(new B4XClass("main"), "calculator.pouya.app.main");
	}

public boolean isSingleton() {
		return true;
	}
     public static RemoteObject getObject() {
		return myClass;
	 }

	public RemoteObject activityBA;
	public RemoteObject _activity;
    private PCBA pcBA;

	public PCBA create(Object[] args) throws ClassNotFoundException{
		processBA = (RemoteObject) args[1];
		activityBA = (RemoteObject) args[2];
		_activity = (RemoteObject) args[3];
        anywheresoftware.b4a.keywords.Common.Density = (Float)args[4];
        remoteMe = (RemoteObject) args[5];
		pcBA = new PCBA(this, main.class);
        main_subs_0.initializeProcessGlobals();
		return pcBA;
	}
public static RemoteObject __c = RemoteObject.declareNull("anywheresoftware.b4a.keywords.Common");
public static RemoteObject _labelview = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _button1didtouch = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _button2didtouch = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _button3didtouch = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _button4didtouch = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _button5didtouch = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _button6didtouch = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _button7didtouch = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _button8didtouch = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _button9didtouch = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _buttonjamdidtouch = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _button0didtouch = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _buttondotdidtouch = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _buttonmenhadidtouch = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _buttonzarbdidtouch = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _buttontaghsimdidtouch = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _buttonmosavididtouch = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _resetbuttondidtouch = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _str1 = RemoteObject.createImmutable("");
public static RemoteObject _str2 = RemoteObject.createImmutable("");
public static RemoteObject _a = RemoteObject.createImmutable(0f);
public static RemoteObject _b = RemoteObject.createImmutable(0f);
public static RemoteObject _s = RemoteObject.createImmutable(0f);
public static RemoteObject _lm = RemoteObject.createImmutable(0);
public static RemoteObject _mystring = RemoteObject.createImmutable("");
public static RemoteObject _outstring = RemoteObject.createImmutable("");
public static RemoteObject _i = RemoteObject.createImmutable(0);
public static RemoteObject _backbuttondidtouch = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static calculator.pouya.app.starter _starter = null;
  public Object[] GetGlobals() {
		return new Object[] {"a",main._a,"Activity",main.mostCurrent._activity,"b",main._b,"backButtonDidTouch",main.mostCurrent._backbuttondidtouch,"button0DidTouch",main.mostCurrent._button0didtouch,"button1DidTouch",main.mostCurrent._button1didtouch,"button2DidTouch",main.mostCurrent._button2didtouch,"button3DidTouch",main.mostCurrent._button3didtouch,"button4DidTouch",main.mostCurrent._button4didtouch,"button5DidTouch",main.mostCurrent._button5didtouch,"button6DidTouch",main.mostCurrent._button6didtouch,"button7DidTouch",main.mostCurrent._button7didtouch,"button8DidTouch",main.mostCurrent._button8didtouch,"button9DidTouch",main.mostCurrent._button9didtouch,"buttonDotDidTouch",main.mostCurrent._buttondotdidtouch,"buttonJamDidTouch",main.mostCurrent._buttonjamdidtouch,"buttonMenhaDidTouch",main.mostCurrent._buttonmenhadidtouch,"buttonMosaviDidTouch",main.mostCurrent._buttonmosavididtouch,"buttonTaghsimDidTouch",main.mostCurrent._buttontaghsimdidtouch,"buttonZarbDidTouch",main.mostCurrent._buttonzarbdidtouch,"i",main._i,"labelView",main.mostCurrent._labelview,"lm",main._lm,"myString",main.mostCurrent._mystring,"outString",main.mostCurrent._outstring,"resetButtonDidTouch",main.mostCurrent._resetbuttondidtouch,"s",main._s,"Starter",Debug.moduleToString(calculator.pouya.app.starter.class),"str1",main.mostCurrent._str1,"str2",main.mostCurrent._str2};
}
}