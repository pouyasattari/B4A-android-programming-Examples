package calculator.pouya.app;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class main_subs_0 {


public static RemoteObject  _activity_create(RemoteObject _firsttime) throws Exception{
try {
		Debug.PushSubsStack("Activity_Create (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,54);
if (RapidSub.canDelegate("activity_create")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","activity_create", _firsttime);}
Debug.locals.put("FirstTime", _firsttime);
 BA.debugLineNum = 54;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
Debug.ShouldStop(2097152);
 BA.debugLineNum = 56;BA.debugLine="Activity.LoadLayout(\"ui1\")";
Debug.ShouldStop(8388608);
main.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("ui1")),main.mostCurrent.activityBA);
 BA.debugLineNum = 57;BA.debugLine="str1= \"\"";
Debug.ShouldStop(16777216);
main.mostCurrent._str1 = BA.ObjectToString("");
 BA.debugLineNum = 58;BA.debugLine="End Sub";
Debug.ShouldStop(33554432);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_pause(RemoteObject _userclosed) throws Exception{
try {
		Debug.PushSubsStack("Activity_Pause (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,64);
if (RapidSub.canDelegate("activity_pause")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","activity_pause", _userclosed);}
Debug.locals.put("UserClosed", _userclosed);
 BA.debugLineNum = 64;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
Debug.ShouldStop(-2147483648);
 BA.debugLineNum = 66;BA.debugLine="End Sub";
Debug.ShouldStop(2);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_resume() throws Exception{
try {
		Debug.PushSubsStack("Activity_Resume (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,60);
if (RapidSub.canDelegate("activity_resume")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","activity_resume");}
 BA.debugLineNum = 60;BA.debugLine="Sub Activity_Resume";
Debug.ShouldStop(134217728);
 BA.debugLineNum = 62;BA.debugLine="End Sub";
Debug.ShouldStop(536870912);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button0didtouch_click() throws Exception{
try {
		Debug.PushSubsStack("button0DidTouch_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,119);
if (RapidSub.canDelegate("button0didtouch_click")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","button0didtouch_click");}
 BA.debugLineNum = 119;BA.debugLine="Sub button0DidTouch_Click";
Debug.ShouldStop(4194304);
 BA.debugLineNum = 120;BA.debugLine="str1 = str1 & \"0\"";
Debug.ShouldStop(8388608);
main.mostCurrent._str1 = RemoteObject.concat(main.mostCurrent._str1,RemoteObject.createImmutable("0"));
 BA.debugLineNum = 121;BA.debugLine="labelView.Text = str1";
Debug.ShouldStop(16777216);
main.mostCurrent._labelview.runMethod(true,"setText",BA.ObjectToCharSequence(main.mostCurrent._str1));
 BA.debugLineNum = 122;BA.debugLine="If labelView.Text = \".\" Then";
Debug.ShouldStop(33554432);
if (RemoteObject.solveBoolean("=",main.mostCurrent._labelview.runMethod(true,"getText"),BA.ObjectToString("."))) { 
 BA.debugLineNum = 123;BA.debugLine="buttonDotDidTouch.Enabled = False";
Debug.ShouldStop(67108864);
main.mostCurrent._buttondotdidtouch.runMethod(true,"setEnabled",main.mostCurrent.__c.getField(true,"False"));
 };
 BA.debugLineNum = 125;BA.debugLine="End Sub";
Debug.ShouldStop(268435456);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button1didtouch_click() throws Exception{
try {
		Debug.PushSubsStack("button1DidTouch_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,69);
if (RapidSub.canDelegate("button1didtouch_click")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","button1didtouch_click");}
 BA.debugLineNum = 69;BA.debugLine="Sub button1DidTouch_Click";
Debug.ShouldStop(16);
 BA.debugLineNum = 70;BA.debugLine="str1 = str1 & \"1\"";
Debug.ShouldStop(32);
main.mostCurrent._str1 = RemoteObject.concat(main.mostCurrent._str1,RemoteObject.createImmutable("1"));
 BA.debugLineNum = 71;BA.debugLine="labelView.Text = str1";
Debug.ShouldStop(64);
main.mostCurrent._labelview.runMethod(true,"setText",BA.ObjectToCharSequence(main.mostCurrent._str1));
 BA.debugLineNum = 72;BA.debugLine="End Sub";
Debug.ShouldStop(128);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button2didtouch_click() throws Exception{
try {
		Debug.PushSubsStack("button2DidTouch_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,74);
if (RapidSub.canDelegate("button2didtouch_click")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","button2didtouch_click");}
 BA.debugLineNum = 74;BA.debugLine="Sub button2DidTouch_Click";
Debug.ShouldStop(512);
 BA.debugLineNum = 75;BA.debugLine="str1 = str1 & \"2\"";
Debug.ShouldStop(1024);
main.mostCurrent._str1 = RemoteObject.concat(main.mostCurrent._str1,RemoteObject.createImmutable("2"));
 BA.debugLineNum = 76;BA.debugLine="labelView.Text = str1";
Debug.ShouldStop(2048);
main.mostCurrent._labelview.runMethod(true,"setText",BA.ObjectToCharSequence(main.mostCurrent._str1));
 BA.debugLineNum = 77;BA.debugLine="End Sub";
Debug.ShouldStop(4096);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button3didtouch_click() throws Exception{
try {
		Debug.PushSubsStack("button3DidTouch_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,79);
if (RapidSub.canDelegate("button3didtouch_click")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","button3didtouch_click");}
 BA.debugLineNum = 79;BA.debugLine="Sub button3DidTouch_Click";
Debug.ShouldStop(16384);
 BA.debugLineNum = 80;BA.debugLine="str1 = str1 & \"3\"";
Debug.ShouldStop(32768);
main.mostCurrent._str1 = RemoteObject.concat(main.mostCurrent._str1,RemoteObject.createImmutable("3"));
 BA.debugLineNum = 81;BA.debugLine="labelView.Text = str1";
Debug.ShouldStop(65536);
main.mostCurrent._labelview.runMethod(true,"setText",BA.ObjectToCharSequence(main.mostCurrent._str1));
 BA.debugLineNum = 82;BA.debugLine="End Sub";
Debug.ShouldStop(131072);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button4didtouch_click() throws Exception{
try {
		Debug.PushSubsStack("button4DidTouch_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,84);
if (RapidSub.canDelegate("button4didtouch_click")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","button4didtouch_click");}
 BA.debugLineNum = 84;BA.debugLine="Sub button4DidTouch_Click";
Debug.ShouldStop(524288);
 BA.debugLineNum = 85;BA.debugLine="str1 = str1 & \"4\"";
Debug.ShouldStop(1048576);
main.mostCurrent._str1 = RemoteObject.concat(main.mostCurrent._str1,RemoteObject.createImmutable("4"));
 BA.debugLineNum = 86;BA.debugLine="labelView.Text = str1";
Debug.ShouldStop(2097152);
main.mostCurrent._labelview.runMethod(true,"setText",BA.ObjectToCharSequence(main.mostCurrent._str1));
 BA.debugLineNum = 87;BA.debugLine="End Sub";
Debug.ShouldStop(4194304);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button5didtouch_click() throws Exception{
try {
		Debug.PushSubsStack("button5DidTouch_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,89);
if (RapidSub.canDelegate("button5didtouch_click")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","button5didtouch_click");}
 BA.debugLineNum = 89;BA.debugLine="Sub button5DidTouch_Click";
Debug.ShouldStop(16777216);
 BA.debugLineNum = 90;BA.debugLine="str1 = str1 & \"5\"";
Debug.ShouldStop(33554432);
main.mostCurrent._str1 = RemoteObject.concat(main.mostCurrent._str1,RemoteObject.createImmutable("5"));
 BA.debugLineNum = 91;BA.debugLine="labelView.Text = str1";
Debug.ShouldStop(67108864);
main.mostCurrent._labelview.runMethod(true,"setText",BA.ObjectToCharSequence(main.mostCurrent._str1));
 BA.debugLineNum = 92;BA.debugLine="End Sub";
Debug.ShouldStop(134217728);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button6didtouch_click() throws Exception{
try {
		Debug.PushSubsStack("button6DidTouch_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,94);
if (RapidSub.canDelegate("button6didtouch_click")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","button6didtouch_click");}
 BA.debugLineNum = 94;BA.debugLine="Sub button6DidTouch_Click";
Debug.ShouldStop(536870912);
 BA.debugLineNum = 95;BA.debugLine="str1 = str1 & \"6\"";
Debug.ShouldStop(1073741824);
main.mostCurrent._str1 = RemoteObject.concat(main.mostCurrent._str1,RemoteObject.createImmutable("6"));
 BA.debugLineNum = 96;BA.debugLine="labelView.Text = str1";
Debug.ShouldStop(-2147483648);
main.mostCurrent._labelview.runMethod(true,"setText",BA.ObjectToCharSequence(main.mostCurrent._str1));
 BA.debugLineNum = 97;BA.debugLine="End Sub";
Debug.ShouldStop(1);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button7didtouch_click() throws Exception{
try {
		Debug.PushSubsStack("button7DidTouch_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,99);
if (RapidSub.canDelegate("button7didtouch_click")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","button7didtouch_click");}
 BA.debugLineNum = 99;BA.debugLine="Sub button7DidTouch_Click";
Debug.ShouldStop(4);
 BA.debugLineNum = 100;BA.debugLine="str1 = str1 & \"7\"";
Debug.ShouldStop(8);
main.mostCurrent._str1 = RemoteObject.concat(main.mostCurrent._str1,RemoteObject.createImmutable("7"));
 BA.debugLineNum = 101;BA.debugLine="labelView.Text = str1";
Debug.ShouldStop(16);
main.mostCurrent._labelview.runMethod(true,"setText",BA.ObjectToCharSequence(main.mostCurrent._str1));
 BA.debugLineNum = 102;BA.debugLine="End Sub";
Debug.ShouldStop(32);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button8didtouch_click() throws Exception{
try {
		Debug.PushSubsStack("button8DidTouch_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,104);
if (RapidSub.canDelegate("button8didtouch_click")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","button8didtouch_click");}
 BA.debugLineNum = 104;BA.debugLine="Sub button8DidTouch_Click";
Debug.ShouldStop(128);
 BA.debugLineNum = 105;BA.debugLine="str1 = str1 & \"8\"";
Debug.ShouldStop(256);
main.mostCurrent._str1 = RemoteObject.concat(main.mostCurrent._str1,RemoteObject.createImmutable("8"));
 BA.debugLineNum = 106;BA.debugLine="labelView.Text = str1";
Debug.ShouldStop(512);
main.mostCurrent._labelview.runMethod(true,"setText",BA.ObjectToCharSequence(main.mostCurrent._str1));
 BA.debugLineNum = 107;BA.debugLine="End Sub";
Debug.ShouldStop(1024);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button9didtouch_click() throws Exception{
try {
		Debug.PushSubsStack("button9DidTouch_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,109);
if (RapidSub.canDelegate("button9didtouch_click")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","button9didtouch_click");}
 BA.debugLineNum = 109;BA.debugLine="Sub button9DidTouch_Click";
Debug.ShouldStop(4096);
 BA.debugLineNum = 110;BA.debugLine="str1 = str1 & \"9\"";
Debug.ShouldStop(8192);
main.mostCurrent._str1 = RemoteObject.concat(main.mostCurrent._str1,RemoteObject.createImmutable("9"));
 BA.debugLineNum = 111;BA.debugLine="labelView.Text = str1";
Debug.ShouldStop(16384);
main.mostCurrent._labelview.runMethod(true,"setText",BA.ObjectToCharSequence(main.mostCurrent._str1));
 BA.debugLineNum = 112;BA.debugLine="End Sub";
Debug.ShouldStop(32768);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _buttondotdidtouch_click() throws Exception{
try {
		Debug.PushSubsStack("buttonDotDidTouch_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,114);
if (RapidSub.canDelegate("buttondotdidtouch_click")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","buttondotdidtouch_click");}
 BA.debugLineNum = 114;BA.debugLine="Sub buttonDotDidTouch_Click";
Debug.ShouldStop(131072);
 BA.debugLineNum = 115;BA.debugLine="str1 = str1 & \".\"";
Debug.ShouldStop(262144);
main.mostCurrent._str1 = RemoteObject.concat(main.mostCurrent._str1,RemoteObject.createImmutable("."));
 BA.debugLineNum = 116;BA.debugLine="labelView.Text = str1";
Debug.ShouldStop(524288);
main.mostCurrent._labelview.runMethod(true,"setText",BA.ObjectToCharSequence(main.mostCurrent._str1));
 BA.debugLineNum = 117;BA.debugLine="End Sub";
Debug.ShouldStop(1048576);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _buttonjamdidtouch_click() throws Exception{
try {
		Debug.PushSubsStack("buttonJamDidTouch_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,127);
if (RapidSub.canDelegate("buttonjamdidtouch_click")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","buttonjamdidtouch_click");}
 BA.debugLineNum = 127;BA.debugLine="Sub buttonJamDidTouch_Click";
Debug.ShouldStop(1073741824);
 BA.debugLineNum = 128;BA.debugLine="str2=str1";
Debug.ShouldStop(-2147483648);
main.mostCurrent._str2 = main.mostCurrent._str1;
 BA.debugLineNum = 129;BA.debugLine="str1= \"\"";
Debug.ShouldStop(1);
main.mostCurrent._str1 = BA.ObjectToString("");
 BA.debugLineNum = 130;BA.debugLine="lm=1";
Debug.ShouldStop(2);
main._lm = BA.numberCast(int.class, 1);
 BA.debugLineNum = 131;BA.debugLine="End Sub";
Debug.ShouldStop(4);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _buttonmenhadidtouch_click() throws Exception{
try {
		Debug.PushSubsStack("buttonMenhaDidTouch_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,133);
if (RapidSub.canDelegate("buttonmenhadidtouch_click")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","buttonmenhadidtouch_click");}
 BA.debugLineNum = 133;BA.debugLine="Sub buttonMenhaDidTouch_Click";
Debug.ShouldStop(16);
 BA.debugLineNum = 134;BA.debugLine="str2=str1";
Debug.ShouldStop(32);
main.mostCurrent._str2 = main.mostCurrent._str1;
 BA.debugLineNum = 135;BA.debugLine="str1= \"\"";
Debug.ShouldStop(64);
main.mostCurrent._str1 = BA.ObjectToString("");
 BA.debugLineNum = 136;BA.debugLine="lm=2";
Debug.ShouldStop(128);
main._lm = BA.numberCast(int.class, 2);
 BA.debugLineNum = 137;BA.debugLine="End Sub";
Debug.ShouldStop(256);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _buttonmosavididtouch_click() throws Exception{
try {
		Debug.PushSubsStack("buttonMosaviDidTouch_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,151);
if (RapidSub.canDelegate("buttonmosavididtouch_click")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","buttonmosavididtouch_click");}
 BA.debugLineNum = 151;BA.debugLine="Sub buttonMosaviDidTouch_Click";
Debug.ShouldStop(4194304);
 BA.debugLineNum = 152;BA.debugLine="a=str2";
Debug.ShouldStop(8388608);
main._a = BA.numberCast(float.class, main.mostCurrent._str2);
 BA.debugLineNum = 153;BA.debugLine="b=str1";
Debug.ShouldStop(16777216);
main._b = BA.numberCast(float.class, main.mostCurrent._str1);
 BA.debugLineNum = 154;BA.debugLine="If lm=1 Then";
Debug.ShouldStop(33554432);
if (RemoteObject.solveBoolean("=",main._lm,BA.numberCast(double.class, 1))) { 
 BA.debugLineNum = 155;BA.debugLine="s=a+b";
Debug.ShouldStop(67108864);
main._s = BA.numberCast(float.class, RemoteObject.solve(new RemoteObject[] {main._a,main._b}, "+",1, 0));
 BA.debugLineNum = 156;BA.debugLine="labelView.Text=s";
Debug.ShouldStop(134217728);
main.mostCurrent._labelview.runMethod(true,"setText",BA.ObjectToCharSequence(main._s));
 };
 BA.debugLineNum = 158;BA.debugLine="If lm=2 Then";
Debug.ShouldStop(536870912);
if (RemoteObject.solveBoolean("=",main._lm,BA.numberCast(double.class, 2))) { 
 BA.debugLineNum = 159;BA.debugLine="s=a-b";
Debug.ShouldStop(1073741824);
main._s = BA.numberCast(float.class, RemoteObject.solve(new RemoteObject[] {main._a,main._b}, "-",1, 0));
 BA.debugLineNum = 160;BA.debugLine="labelView.Text=s";
Debug.ShouldStop(-2147483648);
main.mostCurrent._labelview.runMethod(true,"setText",BA.ObjectToCharSequence(main._s));
 };
 BA.debugLineNum = 162;BA.debugLine="If lm=3 Then";
Debug.ShouldStop(2);
if (RemoteObject.solveBoolean("=",main._lm,BA.numberCast(double.class, 3))) { 
 BA.debugLineNum = 163;BA.debugLine="s=a*b";
Debug.ShouldStop(4);
main._s = BA.numberCast(float.class, RemoteObject.solve(new RemoteObject[] {main._a,main._b}, "*",0, 0));
 BA.debugLineNum = 164;BA.debugLine="labelView.Text=s";
Debug.ShouldStop(8);
main.mostCurrent._labelview.runMethod(true,"setText",BA.ObjectToCharSequence(main._s));
 };
 BA.debugLineNum = 166;BA.debugLine="If lm=4 Then";
Debug.ShouldStop(32);
if (RemoteObject.solveBoolean("=",main._lm,BA.numberCast(double.class, 4))) { 
 BA.debugLineNum = 167;BA.debugLine="s=a/b";
Debug.ShouldStop(64);
main._s = BA.numberCast(float.class, RemoteObject.solve(new RemoteObject[] {main._a,main._b}, "/",0, 0));
 BA.debugLineNum = 168;BA.debugLine="labelView.Text=s";
Debug.ShouldStop(128);
main.mostCurrent._labelview.runMethod(true,"setText",BA.ObjectToCharSequence(main._s));
 };
 BA.debugLineNum = 171;BA.debugLine="End Sub";
Debug.ShouldStop(1024);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _buttontaghsimdidtouch_click() throws Exception{
try {
		Debug.PushSubsStack("buttonTaghsimDidTouch_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,145);
if (RapidSub.canDelegate("buttontaghsimdidtouch_click")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","buttontaghsimdidtouch_click");}
 BA.debugLineNum = 145;BA.debugLine="Sub buttonTaghsimDidTouch_Click";
Debug.ShouldStop(65536);
 BA.debugLineNum = 146;BA.debugLine="str2=str1";
Debug.ShouldStop(131072);
main.mostCurrent._str2 = main.mostCurrent._str1;
 BA.debugLineNum = 147;BA.debugLine="str1= \"\"";
Debug.ShouldStop(262144);
main.mostCurrent._str1 = BA.ObjectToString("");
 BA.debugLineNum = 148;BA.debugLine="lm=4";
Debug.ShouldStop(524288);
main._lm = BA.numberCast(int.class, 4);
 BA.debugLineNum = 149;BA.debugLine="End Sub";
Debug.ShouldStop(1048576);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _buttonzarbdidtouch_click() throws Exception{
try {
		Debug.PushSubsStack("buttonZarbDidTouch_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,139);
if (RapidSub.canDelegate("buttonzarbdidtouch_click")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","buttonzarbdidtouch_click");}
 BA.debugLineNum = 139;BA.debugLine="Sub buttonZarbDidTouch_Click";
Debug.ShouldStop(1024);
 BA.debugLineNum = 140;BA.debugLine="str2=str1";
Debug.ShouldStop(2048);
main.mostCurrent._str2 = main.mostCurrent._str1;
 BA.debugLineNum = 141;BA.debugLine="str1= \"\"";
Debug.ShouldStop(4096);
main.mostCurrent._str1 = BA.ObjectToString("");
 BA.debugLineNum = 142;BA.debugLine="lm=3";
Debug.ShouldStop(8192);
main._lm = BA.numberCast(int.class, 3);
 BA.debugLineNum = 143;BA.debugLine="End Sub";
Debug.ShouldStop(16384);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _globals() throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 26;BA.debugLine="Private labelView As Label";
main.mostCurrent._labelview = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 27;BA.debugLine="Private button1DidTouch As Button";
main.mostCurrent._button1didtouch = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 28;BA.debugLine="Private button2DidTouch As Button";
main.mostCurrent._button2didtouch = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 29;BA.debugLine="Private button3DidTouch As Button";
main.mostCurrent._button3didtouch = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 30;BA.debugLine="Private button4DidTouch As Button";
main.mostCurrent._button4didtouch = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 31;BA.debugLine="Private button5DidTouch As Button";
main.mostCurrent._button5didtouch = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 32;BA.debugLine="Private button6DidTouch As Button";
main.mostCurrent._button6didtouch = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 33;BA.debugLine="Private button7DidTouch As Button";
main.mostCurrent._button7didtouch = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 34;BA.debugLine="Private button8DidTouch As Button";
main.mostCurrent._button8didtouch = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 35;BA.debugLine="Private button9DidTouch As Button";
main.mostCurrent._button9didtouch = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 36;BA.debugLine="Private buttonJamDidTouch As Button";
main.mostCurrent._buttonjamdidtouch = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 37;BA.debugLine="Private button0DidTouch As Button";
main.mostCurrent._button0didtouch = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 38;BA.debugLine="Private buttonDotDidTouch As Button";
main.mostCurrent._buttondotdidtouch = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 39;BA.debugLine="Private buttonMenhaDidTouch As Button";
main.mostCurrent._buttonmenhadidtouch = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 40;BA.debugLine="Private buttonZarbDidTouch As Button";
main.mostCurrent._buttonzarbdidtouch = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 41;BA.debugLine="Private buttonTaghsimDidTouch As Button";
main.mostCurrent._buttontaghsimdidtouch = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 42;BA.debugLine="Private buttonMosaviDidTouch As Button";
main.mostCurrent._buttonmosavididtouch = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 43;BA.debugLine="Private resetButtonDidTouch As Button";
main.mostCurrent._resetbuttondidtouch = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 45;BA.debugLine="Dim str1,str2 As String";
main.mostCurrent._str1 = RemoteObject.createImmutable("");
main.mostCurrent._str2 = RemoteObject.createImmutable("");
 //BA.debugLineNum = 46;BA.debugLine="Dim a,b,s As Float";
main._a = RemoteObject.createImmutable(0f);
main._b = RemoteObject.createImmutable(0f);
main._s = RemoteObject.createImmutable(0f);
 //BA.debugLineNum = 47;BA.debugLine="Dim lm As Int";
main._lm = RemoteObject.createImmutable(0);
 //BA.debugLineNum = 48;BA.debugLine="Dim myString,outString As String";
main.mostCurrent._mystring = RemoteObject.createImmutable("");
main.mostCurrent._outstring = RemoteObject.createImmutable("");
 //BA.debugLineNum = 49;BA.debugLine="Dim i As Int";
main._i = RemoteObject.createImmutable(0);
 //BA.debugLineNum = 51;BA.debugLine="Private backButtonDidTouch As Button";
main.mostCurrent._backbuttondidtouch = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main_subs_0._process_globals();
starter_subs_0._process_globals();
main.myClass = BA.getDeviceClass ("calculator.pouya.app.main");
starter.myClass = BA.getDeviceClass ("calculator.pouya.app.starter");
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _resetbuttondidtouch_click() throws Exception{
try {
		Debug.PushSubsStack("resetButtonDidTouch_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,173);
if (RapidSub.canDelegate("resetbuttondidtouch_click")) { return calculator.pouya.app.main.remoteMe.runUserSub(false, "main","resetbuttondidtouch_click");}
 BA.debugLineNum = 173;BA.debugLine="Sub resetButtonDidTouch_Click";
Debug.ShouldStop(4096);
 BA.debugLineNum = 174;BA.debugLine="str1=\"\"";
Debug.ShouldStop(8192);
main.mostCurrent._str1 = BA.ObjectToString("");
 BA.debugLineNum = 175;BA.debugLine="str2=\"\"";
Debug.ShouldStop(16384);
main.mostCurrent._str2 = BA.ObjectToString("");
 BA.debugLineNum = 176;BA.debugLine="labelView.Text=\"\"";
Debug.ShouldStop(32768);
main.mostCurrent._labelview.runMethod(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 178;BA.debugLine="End Sub";
Debug.ShouldStop(131072);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}