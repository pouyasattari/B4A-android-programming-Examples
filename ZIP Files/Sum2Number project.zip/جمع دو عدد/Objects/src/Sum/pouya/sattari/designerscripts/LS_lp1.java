package Sum.pouya.sattari.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_lp1{

public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
//BA.debugLineNum = 2;BA.debugLine="AutoScaleAll"[lp1/General script]
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
//BA.debugLineNum = 4;BA.debugLine="text2.Top = text1.Bottom + 7dip"[lp1/General script]
views.get("text2").vw.setTop((int)((views.get("text1").vw.getTop() + views.get("text1").vw.getHeight())+(7d * scale)));
//BA.debugLineNum = 5;BA.debugLine="sButton.Top = text2.Bottom + 15dip"[lp1/General script]
views.get("sbutton").vw.setTop((int)((views.get("text2").vw.getTop() + views.get("text2").vw.getHeight())+(15d * scale)));
//BA.debugLineNum = 6;BA.debugLine="Label1.Top = sButton.Bottom +17dip"[lp1/General script]
views.get("label1").vw.setTop((int)((views.get("sbutton").vw.getTop() + views.get("sbutton").vw.getHeight())+(17d * scale)));

}
}