<?php
echo "data1#2345";
echo "<br>";
echo "data2#6666";


?>