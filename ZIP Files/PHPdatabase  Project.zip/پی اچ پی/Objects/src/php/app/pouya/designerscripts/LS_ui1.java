package php.app.pouya.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_ui1{

public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
//BA.debugLineNum = 2;BA.debugLine="AutoScaleAll"[ui1/General script]
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
//BA.debugLineNum = 3;BA.debugLine="ListView1.SetLeftAndRight (45,83%x)"[ui1/General script]
views.get("listview1").vw.setLeft((int)(45d));
views.get("listview1").vw.setWidth((int)((83d / 100 * width) - (45d)));
//BA.debugLineNum = 4;BA.debugLine="ListView1.SetTopAndBottom (40,50%y)"[ui1/General script]
views.get("listview1").vw.setTop((int)(40d));
views.get("listview1").vw.setHeight((int)((50d / 100 * height) - (40d)));
//BA.debugLineNum = 6;BA.debugLine="Button1.SetLeftAndRight (65,77%x)"[ui1/General script]
views.get("button1").vw.setLeft((int)(65d));
views.get("button1").vw.setWidth((int)((77d / 100 * width) - (65d)));
//BA.debugLineNum = 7;BA.debugLine="Button1.SetTopAndBottom (10,10%y)"[ui1/General script]
views.get("button1").vw.setTop((int)(10d));
views.get("button1").vw.setHeight((int)((10d / 100 * height) - (10d)));
//BA.debugLineNum = 8;BA.debugLine="Button1.Top = ListView1.Bottom +25dip"[ui1/General script]
views.get("button1").vw.setTop((int)((views.get("listview1").vw.getTop() + views.get("listview1").vw.getHeight())+(25d * scale)));

}
}