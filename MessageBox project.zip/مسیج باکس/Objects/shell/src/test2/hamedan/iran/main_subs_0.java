package test2.hamedan.iran;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class main_subs_0 {


public static RemoteObject  _activity_create(RemoteObject _firsttime) throws Exception{
try {
		Debug.PushSubsStack("Activity_Create (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,31);
if (RapidSub.canDelegate("activity_create")) { return test2.hamedan.iran.main.remoteMe.runUserSub(false, "main","activity_create", _firsttime);}
Debug.locals.put("FirstTime", _firsttime);
 BA.debugLineNum = 31;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
Debug.ShouldStop(1073741824);
 BA.debugLineNum = 33;BA.debugLine="Activity.LoadLayout(\"ui1\")";
Debug.ShouldStop(1);
main.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("ui1")),main.mostCurrent.activityBA);
 BA.debugLineNum = 35;BA.debugLine="End Sub";
Debug.ShouldStop(4);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_pause(RemoteObject _userclosed) throws Exception{
try {
		Debug.PushSubsStack("Activity_Pause (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,41);
if (RapidSub.canDelegate("activity_pause")) { return test2.hamedan.iran.main.remoteMe.runUserSub(false, "main","activity_pause", _userclosed);}
Debug.locals.put("UserClosed", _userclosed);
 BA.debugLineNum = 41;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
Debug.ShouldStop(256);
 BA.debugLineNum = 43;BA.debugLine="End Sub";
Debug.ShouldStop(1024);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_resume() throws Exception{
try {
		Debug.PushSubsStack("Activity_Resume (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,37);
if (RapidSub.canDelegate("activity_resume")) { return test2.hamedan.iran.main.remoteMe.runUserSub(false, "main","activity_resume");}
 BA.debugLineNum = 37;BA.debugLine="Sub Activity_Resume";
Debug.ShouldStop(16);
 BA.debugLineNum = 39;BA.debugLine="End Sub";
Debug.ShouldStop(64);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _globals() throws Exception{
 //BA.debugLineNum = 22;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 26;BA.debugLine="Private msg1 As Button";
main.mostCurrent._msg1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 27;BA.debugLine="Private msg2 As Button";
main.mostCurrent._msg2 = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 28;BA.debugLine="Private msg3 As Button";
main.mostCurrent._msg3 = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _msg1_click() throws Exception{
try {
		Debug.PushSubsStack("msg1_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,46);
if (RapidSub.canDelegate("msg1_click")) { return test2.hamedan.iran.main.remoteMe.runUserSub(false, "main","msg1_click");}
 BA.debugLineNum = 46;BA.debugLine="Sub msg1_Click";
Debug.ShouldStop(8192);
 BA.debugLineNum = 47;BA.debugLine="Msgbox(\"این تست است\",\"تایتل \")";
Debug.ShouldStop(16384);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence("این تست است")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("تایتل "))),main.mostCurrent.activityBA);
 BA.debugLineNum = 48;BA.debugLine="End Sub";
Debug.ShouldStop(32768);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _msg2_click() throws Exception{
try {
		Debug.PushSubsStack("msg2_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,50);
if (RapidSub.canDelegate("msg2_click")) { return test2.hamedan.iran.main.remoteMe.runUserSub(false, "main","msg2_click");}
RemoteObject _x = RemoteObject.createImmutable(0);
 BA.debugLineNum = 50;BA.debugLine="Sub msg2_Click";
Debug.ShouldStop(131072);
 BA.debugLineNum = 51;BA.debugLine="Dim x As Int";
Debug.ShouldStop(262144);
_x = RemoteObject.createImmutable(0);Debug.locals.put("x", _x);
 BA.debugLineNum = 52;BA.debugLine="x=Msgbox2(\"این  تست \",\"تایتل \",\"آری؟\",\"نه.\",\"لغو\"";
Debug.ShouldStop(524288);
_x = main.mostCurrent.__c.runMethodAndSync(true,"Msgbox2",(Object)(BA.ObjectToCharSequence("این  تست ")),(Object)(BA.ObjectToCharSequence("تایتل ")),(Object)(BA.ObjectToString("آری؟")),(Object)(BA.ObjectToString("نه.")),(Object)(BA.ObjectToString("لغو")),(Object)((main.mostCurrent.__c.getField(false,"Null"))),main.mostCurrent.activityBA);Debug.locals.put("x", _x);
 BA.debugLineNum = 53;BA.debugLine="If x=DialogResponse.POSITIVE Then";
Debug.ShouldStop(1048576);
if (RemoteObject.solveBoolean("=",_x,BA.numberCast(double.class, main.mostCurrent.__c.getField(false,"DialogResponse").getField(true,"POSITIVE")))) { 
 };
 BA.debugLineNum = 56;BA.debugLine="If x=DialogResponse.NEGATIVE Then";
Debug.ShouldStop(8388608);
if (RemoteObject.solveBoolean("=",_x,BA.numberCast(double.class, main.mostCurrent.__c.getField(false,"DialogResponse").getField(true,"NEGATIVE")))) { 
 };
 BA.debugLineNum = 59;BA.debugLine="If x=DialogResponse.CANCEL  Then";
Debug.ShouldStop(67108864);
if (RemoteObject.solveBoolean("=",_x,BA.numberCast(double.class, main.mostCurrent.__c.getField(false,"DialogResponse").getField(true,"CANCEL")))) { 
 };
 BA.debugLineNum = 62;BA.debugLine="End Sub";
Debug.ShouldStop(536870912);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _msg3_click() throws Exception{
try {
		Debug.PushSubsStack("msg3_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,64);
if (RapidSub.canDelegate("msg3_click")) { return test2.hamedan.iran.main.remoteMe.runUserSub(false, "main","msg3_click");}
 BA.debugLineNum = 64;BA.debugLine="Sub msg3_Click";
Debug.ShouldStop(-2147483648);
 BA.debugLineNum = 65;BA.debugLine="ToastMessageShow(\" تست موقت :)\",False)";
Debug.ShouldStop(1);
main.mostCurrent.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToCharSequence(" تست موقت :)")),(Object)(main.mostCurrent.__c.getField(true,"False")));
 BA.debugLineNum = 66;BA.debugLine="End Sub";
Debug.ShouldStop(2);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main_subs_0._process_globals();
starter_subs_0._process_globals();
main.myClass = BA.getDeviceClass ("test2.hamedan.iran.main");
starter.myClass = BA.getDeviceClass ("test2.hamedan.iran.starter");
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 16;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
}