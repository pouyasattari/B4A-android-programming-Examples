package info.app.pouya.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_ui1{

public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
//BA.debugLineNum = 2;BA.debugLine="AutoScaleAll"[ui1/General script]
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
//BA.debugLineNum = 4;BA.debugLine="TextBox.SetLeftAndRight (40,62%x)"[ui1/General script]
views.get("textbox").vw.setLeft((int)(40d));
views.get("textbox").vw.setWidth((int)((62d / 100 * width) - (40d)));
//BA.debugLineNum = 5;BA.debugLine="nameText.SetLeftAndRight (40,62%x)"[ui1/General script]
views.get("nametext").vw.setLeft((int)(40d));
views.get("nametext").vw.setWidth((int)((62d / 100 * width) - (40d)));
//BA.debugLineNum = 6;BA.debugLine="familyText.SetLeftAndRight (40,62%x)"[ui1/General script]
views.get("familytext").vw.setLeft((int)(40d));
views.get("familytext").vw.setWidth((int)((62d / 100 * width) - (40d)));
//BA.debugLineNum = 7;BA.debugLine="saveButton.SetLeftAndRight (60,50%x)"[ui1/General script]
views.get("savebutton").vw.setLeft((int)(60d));
views.get("savebutton").vw.setWidth((int)((50d / 100 * width) - (60d)));
//BA.debugLineNum = 8;BA.debugLine="label.SetLeftAndRight (35,80%x)"[ui1/General script]
views.get("label").vw.setLeft((int)(35d));
views.get("label").vw.setWidth((int)((80d / 100 * width) - (35d)));

}
}