package info.app.pouya;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class main_subs_2 {


public static RemoteObject  _activity_create(RemoteObject _firsttime) throws Exception{
try {
		Debug.PushSubsStack("Activity_Create (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,35);
if (RapidSub.canDelegate("activity_create")) { return info.app.pouya.main.remoteMe.runUserSub(false, "main","activity_create", _firsttime);}
Debug.locals.put("FirstTime", _firsttime);
 BA.debugLineNum = 35;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
Debug.ShouldStop(4);
 BA.debugLineNum = 36;BA.debugLine="Activity.LoadLayout(\"ui1\")";
Debug.ShouldStop(8);
main.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("ui1")),main.mostCurrent.activityBA);
 BA.debugLineNum = 37;BA.debugLine="End Sub";
Debug.ShouldStop(16);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_pause(RemoteObject _userclosed) throws Exception{
try {
		Debug.PushSubsStack("Activity_Pause (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,42);
if (RapidSub.canDelegate("activity_pause")) { return info.app.pouya.main.remoteMe.runUserSub(false, "main","activity_pause", _userclosed);}
Debug.locals.put("UserClosed", _userclosed);
 BA.debugLineNum = 42;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
Debug.ShouldStop(512);
 BA.debugLineNum = 43;BA.debugLine="End Sub";
Debug.ShouldStop(1024);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_resume() throws Exception{
try {
		Debug.PushSubsStack("Activity_Resume (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,39);
if (RapidSub.canDelegate("activity_resume")) { return info.app.pouya.main.remoteMe.runUserSub(false, "main","activity_resume");}
 BA.debugLineNum = 39;BA.debugLine="Sub Activity_Resume";
Debug.ShouldStop(64);
 BA.debugLineNum = 40;BA.debugLine="End Sub";
Debug.ShouldStop(128);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _globals() throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 26;BA.debugLine="Dim sql1 As SQL";
main.mostCurrent._sql1 = RemoteObject.createNew ("anywheresoftware.b4a.sql.SQL");
 //BA.debugLineNum = 27;BA.debugLine="Dim cur1 As Cursor";
main.mostCurrent._cur1 = RemoteObject.createNew ("anywheresoftware.b4a.sql.SQL.CursorWrapper");
 //BA.debugLineNum = 28;BA.debugLine="Private TextBox As EditText";
main.mostCurrent._textbox = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 29;BA.debugLine="Private nameText As EditText";
main.mostCurrent._nametext = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 30;BA.debugLine="Private familyText As EditText";
main.mostCurrent._familytext = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 31;BA.debugLine="Private label As Label";
main.mostCurrent._label = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 32;BA.debugLine="Private saveButton As Button";
main.mostCurrent._savebutton = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main_subs_0._process_globals();
starter_subs_0._process_globals();
main.myClass = BA.getDeviceClass ("info.app.pouya.main");
starter.myClass = BA.getDeviceClass ("info.app.pouya.starter");
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _savebutton_click() throws Exception{
try {
		Debug.PushSubsStack("saveButton_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,45);
if (RapidSub.canDelegate("savebutton_click")) { return info.app.pouya.main.remoteMe.runUserSub(false, "main","savebutton_click");}
 BA.debugLineNum = 45;BA.debugLine="Sub saveButton_Click";
Debug.ShouldStop(4096);
 BA.debugLineNum = 46;BA.debugLine="If File.Exists(File.DirInternal,\"mydb1.db\")=False";
Debug.ShouldStop(8192);
if (RemoteObject.solveBoolean("=",main.mostCurrent.__c.getField(false,"File").runMethod(true,"Exists",(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirInternal")),(Object)(RemoteObject.createImmutable("mydb1.db"))),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 47;BA.debugLine="File.Copy(File.DirAssets,\"mydb.db\",File.DirInter";
Debug.ShouldStop(16384);
main.mostCurrent.__c.getField(false,"File").runVoidMethod ("Copy",(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirAssets")),(Object)(BA.ObjectToString("mydb.db")),(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirInternal")),(Object)(RemoteObject.createImmutable("mydb1.db")));
 };
 BA.debugLineNum = 49;BA.debugLine="If sql1.IsInitialized = False Then";
Debug.ShouldStop(65536);
if (RemoteObject.solveBoolean("=",main.mostCurrent._sql1.runMethod(true,"IsInitialized"),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 50;BA.debugLine="sql1.Initialize(File.DirInternal,\"mydb1.db\",Fa";
Debug.ShouldStop(131072);
main.mostCurrent._sql1.runVoidMethod ("Initialize",(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirInternal")),(Object)(BA.ObjectToString("mydb1.db")),(Object)(main.mostCurrent.__c.getField(true,"False")));
 };
 BA.debugLineNum = 52;BA.debugLine="sql1.ExecNonQuery(\"insert into tbl1 (id,name,";
Debug.ShouldStop(524288);
main.mostCurrent._sql1.runVoidMethod ("ExecNonQuery",(Object)(RemoteObject.concat(RemoteObject.createImmutable("insert into tbl1 (id,name,family) values  ('"),main.mostCurrent._textbox.runMethod(true,"getText"),RemoteObject.createImmutable("','"),main.mostCurrent._nametext.runMethod(true,"getText"),RemoteObject.createImmutable("','"),main.mostCurrent._familytext.runMethod(true,"getText"),RemoteObject.createImmutable("')"))));
 BA.debugLineNum = 53;BA.debugLine="updatelbl";
Debug.ShouldStop(1048576);
_updatelbl();
 BA.debugLineNum = 54;BA.debugLine="End Sub";
Debug.ShouldStop(2097152);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _updatelbl() throws Exception{
try {
		Debug.PushSubsStack("updatelbl (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,56);
if (RapidSub.canDelegate("updatelbl")) { return info.app.pouya.main.remoteMe.runUserSub(false, "main","updatelbl");}
RemoteObject _s1 = RemoteObject.createImmutable("");
int _i = 0;
 BA.debugLineNum = 56;BA.debugLine="Sub updatelbl";
Debug.ShouldStop(8388608);
 BA.debugLineNum = 57;BA.debugLine="cur1=sql1.ExecQuery(\"select * from tbl1\")";
Debug.ShouldStop(16777216);
main.mostCurrent._cur1.setObject(main.mostCurrent._sql1.runMethod(false,"ExecQuery",(Object)(RemoteObject.createImmutable("select * from tbl1"))));
 BA.debugLineNum = 58;BA.debugLine="Dim s1 As String";
Debug.ShouldStop(33554432);
_s1 = RemoteObject.createImmutable("");Debug.locals.put("s1", _s1);
 BA.debugLineNum = 59;BA.debugLine="For i=0 To cur1.RowCount-1";
Debug.ShouldStop(67108864);
{
final int step3 = 1;
final int limit3 = RemoteObject.solve(new RemoteObject[] {main.mostCurrent._cur1.runMethod(true,"getRowCount"),RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
_i = 0 ;
for (;(step3 > 0 && _i <= limit3) || (step3 < 0 && _i >= limit3) ;_i = ((int)(0 + _i + step3))  ) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 60;BA.debugLine="cur1.Position=i";
Debug.ShouldStop(134217728);
main.mostCurrent._cur1.runMethod(true,"setPosition",BA.numberCast(int.class, _i));
 BA.debugLineNum = 61;BA.debugLine="s1=s1&CRLF&cur1.GetString(\"id\")&\"  |  \"&cur1.";
Debug.ShouldStop(268435456);
_s1 = RemoteObject.concat(_s1,main.mostCurrent.__c.getField(true,"CRLF"),main.mostCurrent._cur1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("id"))),RemoteObject.createImmutable("  |  "),main.mostCurrent._cur1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("name"))),RemoteObject.createImmutable("  |  "),main.mostCurrent._cur1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("family"))));Debug.locals.put("s1", _s1);
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 63;BA.debugLine="label.Text=s1";
Debug.ShouldStop(1073741824);
main.mostCurrent._label.runMethod(true,"setText",BA.ObjectToCharSequence(_s1));
 BA.debugLineNum = 64;BA.debugLine="End Sub";
Debug.ShouldStop(-2147483648);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}