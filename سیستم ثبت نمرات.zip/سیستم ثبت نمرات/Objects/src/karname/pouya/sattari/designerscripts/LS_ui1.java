package karname.pouya.sattari.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_ui1{

public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
//BA.debugLineNum = 2;BA.debugLine="AutoScaleAll"[ui1/General script]
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
//BA.debugLineNum = 4;BA.debugLine="nameText.SetLeftAndRight (39,45%x)"[ui1/General script]
views.get("nametext").vw.setLeft((int)(39d));
views.get("nametext").vw.setWidth((int)((45d / 100 * width) - (39d)));
//BA.debugLineNum = 5;BA.debugLine="familyName.Left = nameText.Right +15dip"[ui1/General script]
views.get("familyname").vw.setLeft((int)((views.get("nametext").vw.getLeft() + views.get("nametext").vw.getWidth())+(15d * scale)));
//BA.debugLineNum = 7;BA.debugLine="familyName.Left = 200"[ui1/General script]
views.get("familyname").vw.setLeft((int)(200d));
//BA.debugLineNum = 8;BA.debugLine="nomre1.SetLeftAndRight (39,33%x)"[ui1/General script]
views.get("nomre1").vw.setLeft((int)(39d));
views.get("nomre1").vw.setWidth((int)((33d / 100 * width) - (39d)));
//BA.debugLineNum = 9;BA.debugLine="nomre2.SetLeftAndRight (39,33%x)"[ui1/General script]
views.get("nomre2").vw.setLeft((int)(39d));
views.get("nomre2").vw.setWidth((int)((33d / 100 * width) - (39d)));
//BA.debugLineNum = 10;BA.debugLine="nomre3.SetLeftAndRight (39,33%x)"[ui1/General script]
views.get("nomre3").vw.setLeft((int)(39d));
views.get("nomre3").vw.setWidth((int)((33d / 100 * width) - (39d)));
//BA.debugLineNum = 11;BA.debugLine="nomre2.Left = nomre1.Right +12dip"[ui1/General script]
views.get("nomre2").vw.setLeft((int)((views.get("nomre1").vw.getLeft() + views.get("nomre1").vw.getWidth())+(12d * scale)));
//BA.debugLineNum = 12;BA.debugLine="nomre3.Left = nomre2.Right +12dip"[ui1/General script]
views.get("nomre3").vw.setLeft((int)((views.get("nomre2").vw.getLeft() + views.get("nomre2").vw.getWidth())+(12d * scale)));
//BA.debugLineNum = 14;BA.debugLine="ghabool.Bottom = result.Bottom"[ui1/General script]
views.get("ghabool").vw.setTop((int)((views.get("result").vw.getTop() + views.get("result").vw.getHeight()) - (views.get("ghabool").vw.getHeight())));
//BA.debugLineNum = 15;BA.debugLine="mardood.Bottom = result.Bottom"[ui1/General script]
views.get("mardood").vw.setTop((int)((views.get("result").vw.getTop() + views.get("result").vw.getHeight()) - (views.get("mardood").vw.getHeight())));
//BA.debugLineNum = 17;BA.debugLine="compute_avarage.SetLeftAndRight (39,45%x)"[ui1/General script]
views.get("compute_avarage").vw.setLeft((int)(39d));
views.get("compute_avarage").vw.setWidth((int)((45d / 100 * width) - (39d)));
//BA.debugLineNum = 18;BA.debugLine="clear.Left = compute_avarage.Right +15dip"[ui1/General script]
views.get("clear").vw.setLeft((int)((views.get("compute_avarage").vw.getLeft() + views.get("compute_avarage").vw.getWidth())+(15d * scale)));
//BA.debugLineNum = 20;BA.debugLine="avarage.SetLeftAndRight (45,40%x)"[ui1/General script]
views.get("avarage").vw.setLeft((int)(45d));
views.get("avarage").vw.setWidth((int)((40d / 100 * width) - (45d)));
//BA.debugLineNum = 21;BA.debugLine="avrage_value.Left = avarage.Right + 12dip"[ui1/General script]
views.get("avrage_value").vw.setLeft((int)((views.get("avarage").vw.getLeft() + views.get("avarage").vw.getWidth())+(12d * scale)));
//BA.debugLineNum = 23;BA.debugLine="student_result.SetLeftAndRight (45,40%x)"[ui1/General script]
views.get("student_result").vw.setLeft((int)(45d));
views.get("student_result").vw.setWidth((int)((40d / 100 * width) - (45d)));
//BA.debugLineNum = 24;BA.debugLine="result.Left = student_result.Right + 12dip"[ui1/General script]
views.get("result").vw.setLeft((int)((views.get("student_result").vw.getLeft() + views.get("student_result").vw.getWidth())+(12d * scale)));
//BA.debugLineNum = 26;BA.debugLine="sabtButton.SetLeftAndRight (45,80%x)"[ui1/General script]
views.get("sabtbutton").vw.setLeft((int)(45d));
views.get("sabtbutton").vw.setWidth((int)((80d / 100 * width) - (45d)));
//BA.debugLineNum = 27;BA.debugLine="showLabel.SetLeftAndRight (45,80%x)"[ui1/General script]
views.get("showlabel").vw.setLeft((int)(45d));
views.get("showlabel").vw.setWidth((int)((80d / 100 * width) - (45d)));
//BA.debugLineNum = 29;BA.debugLine="nameText.SetTopAndBottom (40,25%x)"[ui1/General script]
views.get("nametext").vw.setTop((int)(40d));
views.get("nametext").vw.setHeight((int)((25d / 100 * width) - (40d)));
//BA.debugLineNum = 30;BA.debugLine="nomre1.Top = nameText.Bottom + 10dip"[ui1/General script]
views.get("nomre1").vw.setTop((int)((views.get("nametext").vw.getTop() + views.get("nametext").vw.getHeight())+(10d * scale)));
//BA.debugLineNum = 31;BA.debugLine="compute_avarage.Top = nomre1.Bottom + 10dip"[ui1/General script]
views.get("compute_avarage").vw.setTop((int)((views.get("nomre1").vw.getTop() + views.get("nomre1").vw.getHeight())+(10d * scale)));
//BA.debugLineNum = 32;BA.debugLine="avarage.Top = compute_avarage.Bottom + 10dip"[ui1/General script]
views.get("avarage").vw.setTop((int)((views.get("compute_avarage").vw.getTop() + views.get("compute_avarage").vw.getHeight())+(10d * scale)));
//BA.debugLineNum = 33;BA.debugLine="student_result.Top = avarage.Bottom + 10dip"[ui1/General script]
views.get("student_result").vw.setTop((int)((views.get("avarage").vw.getTop() + views.get("avarage").vw.getHeight())+(10d * scale)));
//BA.debugLineNum = 34;BA.debugLine="sabtButton.Top = student_result.Bottom + 10dip"[ui1/General script]
views.get("sabtbutton").vw.setTop((int)((views.get("student_result").vw.getTop() + views.get("student_result").vw.getHeight())+(10d * scale)));
//BA.debugLineNum = 35;BA.debugLine="showLabel.Top = sabtButton.Bottom + 10dip"[ui1/General script]
views.get("showlabel").vw.setTop((int)((views.get("sabtbutton").vw.getTop() + views.get("sabtbutton").vw.getHeight())+(10d * scale)));

}
}