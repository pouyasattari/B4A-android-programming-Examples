package karname.pouya.sattari;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class main_subs_0 {


public static RemoteObject  _activity_create(RemoteObject _firsttime) throws Exception{
try {
		Debug.PushSubsStack("Activity_Create (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,45);
if (RapidSub.canDelegate("activity_create")) { return karname.pouya.sattari.main.remoteMe.runUserSub(false, "main","activity_create", _firsttime);}
Debug.locals.put("FirstTime", _firsttime);
 BA.debugLineNum = 45;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
Debug.ShouldStop(4096);
 BA.debugLineNum = 46;BA.debugLine="Activity.LoadLayout(\"ui1\")";
Debug.ShouldStop(8192);
main.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("ui1")),main.mostCurrent.activityBA);
 BA.debugLineNum = 47;BA.debugLine="End Sub";
Debug.ShouldStop(16384);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_pause(RemoteObject _userclosed) throws Exception{
try {
		Debug.PushSubsStack("Activity_Pause (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,52);
if (RapidSub.canDelegate("activity_pause")) { return karname.pouya.sattari.main.remoteMe.runUserSub(false, "main","activity_pause", _userclosed);}
Debug.locals.put("UserClosed", _userclosed);
 BA.debugLineNum = 52;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
Debug.ShouldStop(524288);
 BA.debugLineNum = 53;BA.debugLine="End Sub";
Debug.ShouldStop(1048576);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_resume() throws Exception{
try {
		Debug.PushSubsStack("Activity_Resume (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,49);
if (RapidSub.canDelegate("activity_resume")) { return karname.pouya.sattari.main.remoteMe.runUserSub(false, "main","activity_resume");}
 BA.debugLineNum = 49;BA.debugLine="Sub Activity_Resume";
Debug.ShouldStop(65536);
 BA.debugLineNum = 50;BA.debugLine="End Sub";
Debug.ShouldStop(131072);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _clear_click() throws Exception{
try {
		Debug.PushSubsStack("clear_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,83);
if (RapidSub.canDelegate("clear_click")) { return karname.pouya.sattari.main.remoteMe.runUserSub(false, "main","clear_click");}
 BA.debugLineNum = 83;BA.debugLine="Sub clear_Click";
Debug.ShouldStop(262144);
 BA.debugLineNum = 84;BA.debugLine="nomre1.Text=\"\"";
Debug.ShouldStop(524288);
main.mostCurrent._nomre1.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 85;BA.debugLine="nomre2.Text=\"\"";
Debug.ShouldStop(1048576);
main.mostCurrent._nomre2.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 86;BA.debugLine="nomre3.Text=\"\"";
Debug.ShouldStop(2097152);
main.mostCurrent._nomre3.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 87;BA.debugLine="result.Text=\"\"";
Debug.ShouldStop(4194304);
main.mostCurrent._result.runMethod(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 88;BA.debugLine="result2.Text=\"\"";
Debug.ShouldStop(8388608);
main.mostCurrent._result2.runMethod(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 89;BA.debugLine="avrage_value.Text=\"\"";
Debug.ShouldStop(16777216);
main.mostCurrent._avrage_value.runMethod(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 90;BA.debugLine="ghabool.Text=\"\"";
Debug.ShouldStop(33554432);
main.mostCurrent._ghabool.runMethod(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 91;BA.debugLine="mardood.Text=\"\"";
Debug.ShouldStop(67108864);
main.mostCurrent._mardood.runMethod(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 92;BA.debugLine="End Sub";
Debug.ShouldStop(134217728);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _compute_avarage_click() throws Exception{
try {
		Debug.PushSubsStack("compute_avarage_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,56);
if (RapidSub.canDelegate("compute_avarage_click")) { return karname.pouya.sattari.main.remoteMe.runUserSub(false, "main","compute_avarage_click");}
 BA.debugLineNum = 56;BA.debugLine="Sub compute_avarage_Click";
Debug.ShouldStop(8388608);
 BA.debugLineNum = 57;BA.debugLine="If nomre1.Text=\"\" Then";
Debug.ShouldStop(16777216);
if (RemoteObject.solveBoolean("=",main.mostCurrent._nomre1.runMethod(true,"getText"),BA.ObjectToString(""))) { 
 BA.debugLineNum = 58;BA.debugLine="Msgbox(\"نمره آزمون اول را درج نمایید\",\"اخطار\")";
Debug.ShouldStop(33554432);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence("نمره آزمون اول را درج نمایید")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("اخطار"))),main.mostCurrent.activityBA);
 }else 
{ BA.debugLineNum = 59;BA.debugLine="Else If nomre2.Text=\"\" Then";
Debug.ShouldStop(67108864);
if (RemoteObject.solveBoolean("=",main.mostCurrent._nomre2.runMethod(true,"getText"),BA.ObjectToString(""))) { 
 BA.debugLineNum = 60;BA.debugLine="Msgbox(\"نمره آزمون دوم را درج نمایید\",\"اخطار\")";
Debug.ShouldStop(134217728);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence("نمره آزمون دوم را درج نمایید")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("اخطار"))),main.mostCurrent.activityBA);
 }else 
{ BA.debugLineNum = 61;BA.debugLine="else If nomre3.Text=\"\" Then";
Debug.ShouldStop(268435456);
if (RemoteObject.solveBoolean("=",main.mostCurrent._nomre3.runMethod(true,"getText"),BA.ObjectToString(""))) { 
 BA.debugLineNum = 62;BA.debugLine="Msgbox(\"نمره آزمون سوم را درج نمایید\",\"اخطار\")";
Debug.ShouldStop(536870912);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence("نمره آزمون سوم را درج نمایید")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("اخطار"))),main.mostCurrent.activityBA);
 }else 
{ BA.debugLineNum = 64;BA.debugLine="Else If nameText.Text=\"\" Then";
Debug.ShouldStop(-2147483648);
if (RemoteObject.solveBoolean("=",main.mostCurrent._nametext.runMethod(true,"getText"),BA.ObjectToString(""))) { 
 BA.debugLineNum = 65;BA.debugLine="Msgbox(\"نام را درج نمایید\",\"اخطار\")";
Debug.ShouldStop(1);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence("نام را درج نمایید")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("اخطار"))),main.mostCurrent.activityBA);
 }else 
{ BA.debugLineNum = 67;BA.debugLine="Else If familyName.Text=\"\" Then";
Debug.ShouldStop(4);
if (RemoteObject.solveBoolean("=",main.mostCurrent._familyname.runMethod(true,"getText"),BA.ObjectToString(""))) { 
 BA.debugLineNum = 68;BA.debugLine="Msgbox(\"فامیلی را درج نمایید\",\"اخطار\")";
Debug.ShouldStop(8);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence("فامیلی را درج نمایید")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("اخطار"))),main.mostCurrent.activityBA);
 }}}}}
;
 BA.debugLineNum = 71;BA.debugLine="avrage_value.Text= (nomre1.Text + nomre2.Text + n";
Debug.ShouldStop(64);
main.mostCurrent._avrage_value.runMethod(true,"setText",BA.ObjectToCharSequence(RemoteObject.solve(new RemoteObject[] {(RemoteObject.solve(new RemoteObject[] {BA.numberCast(double.class, main.mostCurrent._nomre1.runMethod(true,"getText")),BA.numberCast(double.class, main.mostCurrent._nomre2.runMethod(true,"getText")),BA.numberCast(double.class, main.mostCurrent._nomre3.runMethod(true,"getText"))}, "++",2, 0)),RemoteObject.createImmutable(3)}, "/",0, 0)));
 BA.debugLineNum = 72;BA.debugLine="If avrage_value.Text<10 Then";
Debug.ShouldStop(128);
if (RemoteObject.solveBoolean("<",BA.numberCast(double.class, main.mostCurrent._avrage_value.runMethod(true,"getText")),BA.numberCast(double.class, 10))) { 
 BA.debugLineNum = 73;BA.debugLine="result2.Text=mardood.Text";
Debug.ShouldStop(256);
main.mostCurrent._result2.runMethod(true,"setText",BA.ObjectToCharSequence(main.mostCurrent._mardood.runMethod(true,"getText")));
 }else 
{ BA.debugLineNum = 74;BA.debugLine="Else If avrage_value.Text>=10 Then";
Debug.ShouldStop(512);
if (RemoteObject.solveBoolean("g",BA.numberCast(double.class, main.mostCurrent._avrage_value.runMethod(true,"getText")),BA.numberCast(double.class, 10))) { 
 BA.debugLineNum = 75;BA.debugLine="result.Text=ghabool.Text";
Debug.ShouldStop(1024);
main.mostCurrent._result.runMethod(true,"setText",BA.ObjectToCharSequence(main.mostCurrent._ghabool.runMethod(true,"getText")));
 }}
;
 BA.debugLineNum = 78;BA.debugLine="If result.Text<>\"\"  Then";
Debug.ShouldStop(8192);
if (RemoteObject.solveBoolean("!",main.mostCurrent._result.runMethod(true,"getText"),BA.ObjectToString(""))) { 
 BA.debugLineNum = 79;BA.debugLine="sabtButton.Visible = True";
Debug.ShouldStop(16384);
main.mostCurrent._sabtbutton.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 };
 BA.debugLineNum = 81;BA.debugLine="End Sub";
Debug.ShouldStop(65536);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _globals() throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 24;BA.debugLine="Dim nomre1 As EditText";
main.mostCurrent._nomre1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 25;BA.debugLine="Dim nomre2 As EditText";
main.mostCurrent._nomre2 = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 26;BA.debugLine="Dim nomre3 As EditText";
main.mostCurrent._nomre3 = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 27;BA.debugLine="Dim compute_avarage As Button";
main.mostCurrent._compute_avarage = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 28;BA.debugLine="Dim avrage_value As Label";
main.mostCurrent._avrage_value = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 29;BA.debugLine="Dim result2 As Label";
main.mostCurrent._result2 = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 31;BA.debugLine="Private mardood As Label";
main.mostCurrent._mardood = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 32;BA.debugLine="Private ghabool As Label";
main.mostCurrent._ghabool = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 33;BA.debugLine="Private result As Label";
main.mostCurrent._result = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 35;BA.debugLine="Private sabtButton As Button";
main.mostCurrent._sabtbutton = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 37;BA.debugLine="Private nameText As EditText";
main.mostCurrent._nametext = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 38;BA.debugLine="Private familyName As EditText";
main.mostCurrent._familyname = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 40;BA.debugLine="Dim sql1 As SQL";
main.mostCurrent._sql1 = RemoteObject.createNew ("anywheresoftware.b4a.sql.SQL");
 //BA.debugLineNum = 41;BA.debugLine="Dim cur1 As Cursor";
main.mostCurrent._cur1 = RemoteObject.createNew ("anywheresoftware.b4a.sql.SQL.CursorWrapper");
 //BA.debugLineNum = 42;BA.debugLine="Private showLabel As Label";
main.mostCurrent._showlabel = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 43;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main_subs_0._process_globals();
starter_subs_0._process_globals();
main.myClass = BA.getDeviceClass ("karname.pouya.sattari.main");
starter.myClass = BA.getDeviceClass ("karname.pouya.sattari.starter");
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _sabtbutton_click() throws Exception{
try {
		Debug.PushSubsStack("sabtButton_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,94);
if (RapidSub.canDelegate("sabtbutton_click")) { return karname.pouya.sattari.main.remoteMe.runUserSub(false, "main","sabtbutton_click");}
 BA.debugLineNum = 94;BA.debugLine="Sub sabtButton_Click";
Debug.ShouldStop(536870912);
 BA.debugLineNum = 95;BA.debugLine="If File.Exists(File.DirInternal,\"myDB.db\")=False";
Debug.ShouldStop(1073741824);
if (RemoteObject.solveBoolean("=",main.mostCurrent.__c.getField(false,"File").runMethod(true,"Exists",(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirInternal")),(Object)(RemoteObject.createImmutable("myDB.db"))),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 96;BA.debugLine="File.Copy(File.DirAssets,\"myDB.db\",File.DirInter";
Debug.ShouldStop(-2147483648);
main.mostCurrent.__c.getField(false,"File").runVoidMethod ("Copy",(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirAssets")),(Object)(BA.ObjectToString("myDB.db")),(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirInternal")),(Object)(RemoteObject.createImmutable("myDB.db")));
 };
 BA.debugLineNum = 99;BA.debugLine="If sql1.IsInitialized = False Then";
Debug.ShouldStop(4);
if (RemoteObject.solveBoolean("=",main.mostCurrent._sql1.runMethod(true,"IsInitialized"),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 100;BA.debugLine="sql1.Initialize(File.DirInternal,\"myDB.db\",False";
Debug.ShouldStop(8);
main.mostCurrent._sql1.runVoidMethod ("Initialize",(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirInternal")),(Object)(BA.ObjectToString("myDB.db")),(Object)(main.mostCurrent.__c.getField(true,"False")));
 };
 BA.debugLineNum = 103;BA.debugLine="sql1.ExecNonQuery(\"insert into tbl1 (name,family,";
Debug.ShouldStop(64);
main.mostCurrent._sql1.runVoidMethod ("ExecNonQuery",(Object)(RemoteObject.concat(RemoteObject.createImmutable("insert into tbl1 (name,family,score1,score2,score3,passedORno) values  ('"),main.mostCurrent._nametext.runMethod(true,"getText"),RemoteObject.createImmutable("','"),main.mostCurrent._familyname.runMethod(true,"getText"),RemoteObject.createImmutable("','"),main.mostCurrent._nomre1.runMethod(true,"getText"),RemoteObject.createImmutable("','"),main.mostCurrent._nomre2.runMethod(true,"getText"),RemoteObject.createImmutable("','"),main.mostCurrent._nomre3.runMethod(true,"getText"),RemoteObject.createImmutable("','"),main.mostCurrent._result.runMethod(true,"getText"),RemoteObject.createImmutable("')"))));
 BA.debugLineNum = 105;BA.debugLine="update_label";
Debug.ShouldStop(256);
_update_label();
 BA.debugLineNum = 107;BA.debugLine="End Sub";
Debug.ShouldStop(1024);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _update_label() throws Exception{
try {
		Debug.PushSubsStack("update_label (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,110);
if (RapidSub.canDelegate("update_label")) { return karname.pouya.sattari.main.remoteMe.runUserSub(false, "main","update_label");}
RemoteObject _s1 = RemoteObject.createImmutable("");
int _i = 0;
 BA.debugLineNum = 110;BA.debugLine="Sub update_label";
Debug.ShouldStop(8192);
 BA.debugLineNum = 111;BA.debugLine="cur1=sql1.ExecQuery(\"select * from tbl1\")";
Debug.ShouldStop(16384);
main.mostCurrent._cur1.setObject(main.mostCurrent._sql1.runMethod(false,"ExecQuery",(Object)(RemoteObject.createImmutable("select * from tbl1"))));
 BA.debugLineNum = 112;BA.debugLine="Dim s1 As String";
Debug.ShouldStop(32768);
_s1 = RemoteObject.createImmutable("");Debug.locals.put("s1", _s1);
 BA.debugLineNum = 113;BA.debugLine="For i=0 To cur1.RowCount-1";
Debug.ShouldStop(65536);
{
final int step3 = 1;
final int limit3 = RemoteObject.solve(new RemoteObject[] {main.mostCurrent._cur1.runMethod(true,"getRowCount"),RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
_i = 0 ;
for (;(step3 > 0 && _i <= limit3) || (step3 < 0 && _i >= limit3) ;_i = ((int)(0 + _i + step3))  ) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 114;BA.debugLine="cur1.Position=i";
Debug.ShouldStop(131072);
main.mostCurrent._cur1.runMethod(true,"setPosition",BA.numberCast(int.class, _i));
 BA.debugLineNum = 115;BA.debugLine="s1=s1&CRLF&cur1.GetString(\"name\")&\"  |  \"&cur1.G";
Debug.ShouldStop(262144);
_s1 = RemoteObject.concat(_s1,main.mostCurrent.__c.getField(true,"CRLF"),main.mostCurrent._cur1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("name"))),RemoteObject.createImmutable("  |  "),main.mostCurrent._cur1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("family"))),RemoteObject.createImmutable("  |  "),main.mostCurrent._cur1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("score1"))),main.mostCurrent._cur1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("score2"))),main.mostCurrent._cur1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("score3"))),main.mostCurrent._cur1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("passedORno"))));Debug.locals.put("s1", _s1);
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 118;BA.debugLine="showLabel.Text=s1";
Debug.ShouldStop(2097152);
main.mostCurrent._showlabel.runMethod(true,"setText",BA.ObjectToCharSequence(_s1));
 BA.debugLineNum = 119;BA.debugLine="End Sub";
Debug.ShouldStop(4194304);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}